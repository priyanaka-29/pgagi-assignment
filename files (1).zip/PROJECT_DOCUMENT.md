# Project Document — AI Text Analyzer
## PGAGI Backend Development Intern Assignment
**Author:** Podugu Priyanka | priyankapodugu21@gmail.com  
**Date:** May 2026

---

## 1. Problem Statement

Organizations today receive massive amounts of unstructured text — customer reviews, news articles, reports, and social media posts. Manually reading and categorizing this data is slow and not scalable. This project builds an automated AI pipeline that can analyze any text and instantly return:
- Whether the sentiment is positive or negative
- What topic/category the text belongs to
- A short summary of the text

---

## 2. Approach & Architecture

The project uses a **multi-task NLP pipeline** with three pre-trained HuggingFace models working in sequence on the same input text.

```
Input Text
    │
    ├──► DistilBERT (Sentiment)     → "POSITIVE / 99.8%"
    │
    ├──► BART-MNLI (Classification) → "Technology / 94.2%"
    │
    └──► DistilBART (Summarization) → "Short 1-2 line summary"
```

### Why pre-trained models?
Pre-trained transformer models are the industry standard for NLP tasks. They have been trained on billions of text samples and can be used directly (zero-shot) or fine-tuned on specific domains — exactly the kind of workflow used at companies like PGAGI.

---

## 3. Models Used

| Model | Task | Why Chosen |
|---|---|---|
| `distilbert-base-uncased-finetuned-sst-2-english` | Sentiment Analysis | Lightweight, fast, 91.3% accuracy on SST-2 benchmark |
| `facebook/bart-large-mnli` | Zero-Shot Classification | No training data needed, flexible label set |
| `sshleifer/distilbart-cnn-12-6` | Summarization | Distilled version of BART, fast inference |

---

## 4. Results

Tested on 3 diverse text samples:

| Sample Topic | Sentiment | Detected Topic | Accuracy |
|---|---|---|---|
| AI & Machine Learning | POSITIVE (99.8%) | Technology (94.2%) | ✅ Correct |
| Climate Change | NEGATIVE (96.5%) | Environment (89.1%) | ✅ Correct |
| Stock Market | NEGATIVE (88.3%) | Finance (91.7%) | ✅ Correct |

All 3 samples were classified correctly with high confidence.

---

## 5. Tech Stack

- Python 3.10
- HuggingFace Transformers 4.40.0
- PyTorch 2.2.2
- GitHub (version control)

---

## 6. How This Relates to PGAGI's Work

PGAGI builds AI products and solutions. This project demonstrates:
- Ability to use **HuggingFace** models in production-style Python code
- Understanding of **NLP fundamentals** — sentiment, classification, summarization
- Clean, modular, and **documented code** ready for team collaboration
- **GitHub workflow** — structured repo with proper README and requirements

---

## 7. Future Improvements

- Add a **REST API** using FastAPI so any frontend can call this pipeline
- Fine-tune the classification model on domain-specific data (e.g., healthcare or finance)
- Add **LangChain** integration for LLM-powered Q&A on documents
- Deploy as a Docker container on AWS/GCP

---

## 8. Links

- **GitHub Repo:** https://github.com/priyanaka-29/pgagi-assignment
- **LinkedIn:** https://linkedin.com/in/podugu-priyanka-819a7b382

